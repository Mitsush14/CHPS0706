import matplotlib.pyplot as plt
import numpy as np
class Maillage(object):
    def __init__(self, path):
        (self.nbm,
         self.nbe,
         self.nba,
         self.coord,
         self.tri,
         self.ar,
         self.refn,
         self.reft,
         self.refa) = self.lit_fichier_msh(path)

    def lit_fichier_msh(self, path):
        f = open(path, "r")
        coord = []
        tri = []
        ar = []
        refn = []
        reft = []
        refa = []
        (nbm, nbe, nba) = f.readline().split()
        nbm = int(nbm)
        nbe = int(nbe)
        nba = int(nba)
        for i in range(nbm):
            coord.append(f.readline().split())
            refn.append(int(coord[i][2]))
            del(coord[i][-1])
            for j in range (2):
                coord[i][j] = float(coord[i][j])
        for i in range(nbe):
            tri.append(f.readline().split())
            reft.append(int(tri[i][3]))
            del(tri[i][-1])
            for j in range (3):
                tri[i][j] = int(tri[i][j])
        for i in range(nba):
            ar.append(f.readline().split())
            refa.append(int(ar[i][2]))
            del(ar[i][-1])
            for j in range (2):
                ar[i][j] = int(ar[i][j])
        f.close()

        return (nbm, nbe, nba, coord, tri, ar, refn, reft, refa)

    def trace_maillage_ind(self, nbm, nbe, nba, coord, tri, ar):
        xy = np.asarray(coord)
        x = np.degrees(xy[:, 0])
        y = np.degrees(xy[:, 1])
        triangles = np.asarray(tri)

        fig, ax = plt.subplots()
        ax.set_aspect('equal')
        ax.triplot(x, y, triangles-1, 'go-', lw=1.0)
        plt.show()

    def charge_et_affiche_maillage(fichierMaillage):
        m = Maillage(fichierMaillage)
        m.trace_maillage_ind(m.nbm, m.nbe, m.nba, m.coord, m.tri, m.ar)

    def pas_et_qualite_maillage():
        #calcul distance engre chaque point du triangle et prendre le max
        #pour le pas d'un maillage -> prendre le pas le plus haut sur ts les triangles
        #qualité : prendre le pas du triangle + son rayon isncrit et faire des maths dessus



if __name__ == '__main__':
    Maillage.charge_et_affiche_maillage("Maillages/mini_maillage.msh")
